const PORT = 3000
const app = require('./app');

app.listen(PORT, () => {
    console.log(`Example app listening at http://localhost:${PORT}`)
})